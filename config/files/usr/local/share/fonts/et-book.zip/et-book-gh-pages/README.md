### ET Book

A webfont version of the typeface used in Edward Tufte’s [books](https://www.edwardtufte.com/tufte/books_vdqi).

-------------------------------------

ET Book was designed by Dmitry Krasny, Bonnie Scranton, and [Edward Tufte](https://www.edwardtufte.com/tufte/). It was converted from the original `suit` files by [Adam Schwartz](http://adamschwartz.co) ([@adamschwartz](https://github.com/adamschwartz)).

ET Book is MIT License. You may use it in both personal and commercial projects.
